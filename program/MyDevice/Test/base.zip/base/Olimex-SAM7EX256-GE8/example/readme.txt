Copy these files into your own project directory and alter them to suite.

In particular look at the MYFILES definition and the MYCSRC definition.