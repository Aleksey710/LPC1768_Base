This directory contains the interface for Linux
running either native Linux.

On this board uGFX currently supports:
	- GDISP via the X driver 
	- GINPUT-touch via the X driver

There is an example Makefile and project in the examples directory.

