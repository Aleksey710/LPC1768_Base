This directory contains the interface for the FireBull-FB-STM32F103 board
running ChibiOS/RT.

As this is not a standard ChibiOS/RT supported board, the necessary board files have
also been provided in the chibios_board directory 

