This directory contains the interface for the Embest-STM32-DMSTF4BB board
running ChibiOS/RT.

As this is not a standard ChibiOS/RT supported board, the necessary board files have
also been provided in the chibios_board directory

